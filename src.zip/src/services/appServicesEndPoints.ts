export enum ServicesEndPoints {
  USERS = "/users",
  LOGIN = "/login",
  NEWS = "/news/",
}
