export interface LoginResult {
  userToken: string;
}

export interface LoginParams {
  email: string;
  password: string;
}
