export enum StorageKeys {
  APP_LANGUAGE = 'APP_LANGUAGE',
  IS_APP_LANGUAGE_Selected = 'IS_APP_LANGUAGE_Selected',
  USER_DATA = 'USER_DATA',
  MerchantData = 'MerchantData',
}

export type STORAGES_KEY = StorageKeys;
